# Memory Game Project

## Table of Contents

* [Introduction](#introduction)
* [Instructions](#instructions)
* [Contributing](#contributing)

## Introduction
when the start game, will see 16 of cards thats two of them are pairs. you will win when you matched all of them.

## Instructions
1- Click on the card
2- Click to another card, if they cards identical will they are matches, or if not identical you will try another time.
3- Keep revealing cards and working your memory to remember each unveiled card.
4- When you matches all cards the Congratulation Modal will appear and ask you if you want to play again or close.

## Build
I'm use the starter code and build the dynamic functions in javascrpit.
Use the CSS style and HTML Structure. 