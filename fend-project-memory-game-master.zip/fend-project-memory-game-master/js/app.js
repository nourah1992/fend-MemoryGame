/*jslint es6 */

/*
 * Create a list that holds all of your cards
 */

// deck of all cards in game
const deck = document.getElementById("card-deck");

let card = document.getElementsByClassName("card");

// cards array holds all cards
let cards = [...card];

//array that holds all open cards
let openedCards = [];

// declaring variable of matchedCards
let matchedCard = document.getElementsByClassName("match");

//declaring variable for count of move
let move= document.getElementById("moveCount");
let count=0;

//declaring variables for time calculate
let timer= document.querySelector(".timer");
let s=0, m=0, h=0;
let handle;

//declaring variable for Star Rating
let stars=document.querySelectorAll(".fa-star");

//declaring variable for Congratulation Modal
let modal= document.querySelector(".modal-container");
let closeIcon = document.querySelector(".close");


/*
 * Display the cards on the page
 *   - shuffle the list of cards using the provided "shuffle" method below
 *   - loop through each card and create its HTML
 *   - add each card's HTML to the page
 */
 

// Shuffle function from http://stackoverflow.com/a/2450976
function shuffle(array) {
    let currentIndex = array.length, temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}

//@description the First function will applay in Game
function startGame(){
   let shuffledCards = shuffle(cards);
    
   for (let i= 0; i < shuffledCards.length; i++){
       deck.innerHTML = "";
      [].forEach.call(shuffledCards, function(item){
         deck.appendChild(item);
      });
       cards[i].classList.remove("show", "open", "match", "disabled");
   }
    
    //reset moves
    count=0;
    move.innerHTML=count;
    
    //show stars
    for (var i= 0; i < stars.length; i++){
        stars[i].style.color = "#FFD700";
        stars[i].style.visibility = "visible";
    }
    
    //reset timer
    s=0;
    m=0;
    h=0;
    timer.innerHTML= m+"mins"+s+"s";
    clearInterval(handle);
}

document.body.onload = startGame();

// toggles open and show class to display cards
var displayCard = function (){
   this.classList.toggle("open");
   this.classList.toggle("show");
   this.classList.toggle("disabled");
}

// @description this Function willcalculate the time in minutes and seconds
function TimeCalculate(){
    handle = setInterval(function(){
        timer.innerHTML= m+"mins "+s+"s";
        s++;
        if(s==60){
            m++;
            s=0;
        }
        if(m==60){
            h++;
            m=0;
        }}, 1000); 
}


// @description add opened cards to OpenedCards list and check if cards are match or not
function cardOpen() {
    moveCounter();
    openedCards.push(this);
    let len = openedCards.length;
    if(len === 2){
      if(openedCards[0].type === openedCards[1].type){
            matched();
       } else {
          unmatched();
        }
    }
};

// @description calculate moves and rate
function moveCounter(){
    count++;
    move.innerHTML=count;
    if(count == 1){
        s= 0;
        m= 0; 
        h= 0;
        TimeCalculate();
    }
    
    // setting rates based on moves
    if (count > 18 && count < 24){
        stars[2].style.visibility = "collapse";
    }
        else if (count > 24){
            stars[1].style.visibility = "collapse";
        }
}

// @description when cards matched
function matched(){
    openedCards[0].classList.add("match", "disabled");
    openedCards[1].classList.add("match", "disabled");
    openedCards[0].classList.remove("show", "open", "no-event");
    openedCards[1].classList.remove("show", "open", "no-event");
    openedCards = [];
}

// description when cards don't match
function unmatched(){
    openedCards[0].classList.add("unmatched");
    openedCards[1].classList.add("unmatched");
    disable();
    setTimeout(function(){
        openedCards[0].classList.remove("show", "open", "no-event","unmatched");
        openedCards[1].classList.remove("show", "open", "no-event","unmatched");
        enable();
        openedCards = [];
    },1100);
}


// @description disable cards temporarily
function disable(){
    Array.prototype.filter.call(cards, function(card){
        card.classList.add("disabled");
    });
}

function enable(){
    Array.prototype.filter.call(cards, function(card){
        card.classList.remove("disabled");
        for(var i = 0; i < matchedCard.length; i++){
            matchedCard[i].classList.add("disabled");
        }
    });
}

//@description Congratulation Modal when user Winner
function Congratulation(){
    if (matchedCard.length == 16){
        clearInterval(handle);
        finalTime = timer.innerHTML;
        
        modal.classList.add("show");
        
        // declare star rating variable
        let starRating = document.querySelector(".stars").innerHTML;

        //showing move, rating, time on modal
        document.getElementById("finalMove").innerHTML = count;
        document.getElementById("finalRate").innerHTML = starRating;
        document.getElementById("totalTime").innerHTML = finalTime;
        }
}

// @description close modal button
function closeModal(){
        modal.classList.remove("show");
        startGame();
}

// @description Play Again button
function playAgain(){
    modal.classList.remove("show");
    startGame();
}

// loop to add event listeners to each card
for (var i = 0; i < cards.length; i++){
    cards[i].addEventListener("click", displayCard);
    cards[i].addEventListener("click", cardOpen);
    cards[i].addEventListener("click",Congratulation);
};
/*
 * set up the event listener for a card. If a card is clicked:
 *  - display the card's symbol (put this functionality in another function that you call from this one)
 *  - add the card to a *list* of "open" cards (put this functionality in another function that you call from this one)
 *  - if the list already has another card, check to see if the two cards match
 *    + if the cards do match, lock the cards in the open position (put this functionality in another function that you call from this one)
 *    + if the cards do not match, remove the cards from the list and hide the card's symbol (put this functionality in another function that you call from this one)
 *    + increment the move counter and display it on the page (put this functionality in another function that you call from this one)
 *    + if all cards have matched, display a message with the final score (put this functionality in another function that you call from this one)
 */
